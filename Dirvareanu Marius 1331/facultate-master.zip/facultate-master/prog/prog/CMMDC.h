#pragma once
#include <iostream>

using namespace std;

class CMMDC
{
private :
	int a, b, c, d;
public:
	CMMDC();
	int cmmdcFunc();
	void cmmmc();
	~CMMDC();
};

